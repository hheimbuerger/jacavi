import java.awt.Button;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import com_port.ComListener;
import com_port.ComManager;
import com_port.Message;


public class GLogger extends JFrame implements Runnable,ComListener,ActionListener {

	ComManager cm;
	
	double x, y;
	JTextArea logx,logy;
	
	Integer a;
	
	boolean run;
	public GLogger(ComManager c) {
		// TODO Auto-generated constructor stub
		cm =c;
		cm.addComListener(this,ComManager.FIX_1); //Y
		cm.addComListener(this,ComManager.FIX_2); //x
		 a = new Integer(5);
		JPanel p1,p2;
		p1 = new JPanel();
		p2 = new JPanel();
		
		logx = new JTextArea(20,10);
		logy = new JTextArea(20,10);
		p1.add(logx);
		JScrollPane scrollx = new JScrollPane(logx,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		p1.add(scrollx);
		
		p2.add(logy);
		JScrollPane scrolly = new JScrollPane(logy,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		p2.add(scrolly);
		this.setLayout(new GridLayout(2,2));
		
		this.add(p1);
		this.add(p2);
		logx.append("X-Achse: \n");
		logy.append("Y-Achse: \n");
		x=0;y=0;
		
		Button b = new Button("run");
		b.addActionListener(this);
		this.add(b);
		
		
		run = false;
	}
	@Override
	public void fixDataReceived(byte b, int index) {

		
		int k = 0; 
		k= (short)(0x00FF & b);
		synchronized(a)
		{
		if(index == ComManager.FIX_2) //Y
		{
			y = ((((double)k-128)/127)*5*-1);
			
		}
		else if(index == ComManager.FIX_1)//x
		{
			x = ((((double)k-128)/127)*5*-1);
		
		}
		}
	}

	@Override
	public void msgReceived(Message m, int index) {
		// TODO Auto-generated method stub

	}
	@Override
	public void run() {
		while(true)
		{
		
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(run){
				synchronized(a)
				{
			logx.append((new DecimalFormat("000.00")).format(x)+"\n");
			logy.append((new DecimalFormat("000.00")).format(y)+"\n");
				}
			
		}
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(run)
			run = false;
		else
			run = true;
		
	}

}
