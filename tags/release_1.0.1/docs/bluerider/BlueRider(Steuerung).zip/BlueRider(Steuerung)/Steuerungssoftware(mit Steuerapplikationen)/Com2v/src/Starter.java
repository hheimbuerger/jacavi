import com_port.ComManager;




public class Starter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Starte ComManager");
		ComManager myCmm = ComManager.getInstanceOfCM();
		System.out.println("Verbindung herstellen");
		try {
			myCmm.connect("COM10");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("Verbindung hergestellt");

		
		Pwmcontrol pwc = new Pwmcontrol(myCmm);
		pwc.setVisible(true);
		
		PwmMouse pm = new PwmMouse(myCmm);
		pm.setVisible(true);
		(new Thread(pm)).start();
		
		
		GLogger g = new GLogger(myCmm);
		(new Thread(g)).start();
		g.setVisible(true);
		
		
		//pwc.show();
		
		//(new Thread(new Pwmtest(myCmm))).start();
		

	}

}
