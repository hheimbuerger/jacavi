import com_port.ComException;
import com_port.ComListener;
import com_port.ComManager;
import com_port.Message;



public class Pwmtest implements Runnable, ComListener
{
	ComManager myCmm;
	
	Object b;
	byte value;
	double time;
	double ges;
	int anz;
	
	double min,max;
	
	public Pwmtest(ComManager c) 
	{
		myCmm  = c;
		myCmm.addComListener(this,ComManager.FIX_0);
		
		b = new Object();
		ges = 0;
		anz = 0;
		min = 0;
		max = 0;
	}
	
	public void run()
	{
		value = 0;
		while(true)
		{
			
			try {
				myCmm.setFixData(ComManager.FIX_0, (byte)value);
			} catch (ComException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	/*
			time = System.currentTimeMillis();
		
			
			
			synchronized(b)
			{
				try {
					b.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		*/	
			value+=1;
			
		}
	}

	@Override
	public void msgReceived(Message m, int index) {
		

		
	}

	@Override
	public void fixDataReceived(byte b, int index) {
	/*	
		double delta = System.currentTimeMillis() - time;
		ges += delta;
		anz++;
		
		if(min == 0)
		{
			min =delta;
		}
		else
		{
			if(min > delta)
				min = delta;
		}
		
		if(max < delta)
			max = delta;
		
		if(anz > 5000)
		{
			value = 0;
			System.out.println("------------------------------");
			System.out.println("PWM Durchschnitt: "+ges/anz);
			System.out.println("Max             : "+max);
			System.out.println("Min             : "+min);	
			System.out.println("------------------------------");
			ges =0;
			anz=0;
			min = 0;
			max = 0;
		}
		
		synchronized(this.b)
		{
			this.b.notify();
		}
		*/
	}
	
}