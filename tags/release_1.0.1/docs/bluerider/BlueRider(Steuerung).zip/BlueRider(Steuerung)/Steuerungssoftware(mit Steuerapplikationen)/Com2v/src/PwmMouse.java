import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JFrame;
import javax.swing.JProgressBar;


import com_port.ComException;
import com_port.ComListener;
import com_port.ComManager;
import com_port.Message;


public class PwmMouse extends JFrame implements MouseMotionListener, ComListener, MouseListener, KeyListener, Runnable {

	
	ComManager myCMM;
	JProgressBar bar;
	double time;
	
	int lastY;
	double base;
	boolean first;
	 
	Boolean accel;
	Boolean braking;

	public PwmMouse(ComManager c)
	{
		// TODO Auto-generated constructor stub
		myCMM = c;
		myCMM.addComListener(this,ComManager.FIX_0);
		
		bar = new JProgressBar( 0, 255 );
		first = true;

		accel = new Boolean(false);
		braking = new Boolean(false);
	    this.setMinimumSize(new Dimension(500,500));
		this.setTitle("Maus Controller");
		
	    base = 471;
	    
		this.add( bar, BorderLayout.PAGE_START ); 
 	    
		this.addKeyListener(this);
		
	    this.addMouseMotionListener(this);
	    this.addMouseListener(this);
	}
	@Override
	public void msgReceived(Message m, int index) {

	}
	@Override
	public void fixDataReceived(byte b, int index) 
	{
		short a = (short)(0x00FF & b);
		bar.setValue(a);
		
	}
	
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		if(first)
			lastY = e.getY();
		
		byte value;
		
		synchronized(braking)
		{
			if(braking)
				return;
		}
	
		if(e.getY() > 24 && e.getY() < 495)
		{	
			value = (byte)((e.getY()-24)*(255/base)) ;

		}
		else if(e.getY()<=24)
		{
			value = (byte)0;
		}
		else
		{
			value = (byte)255;
		}
		
		System.out.println(value);
    	try 
    	{
			myCMM.setFixData(ComManager.FIX_0, (byte) value);
		} 
    	catch (ComException e1) 
    	{
			if(e1.getReason() == ComException.FAILSAFE)
			{
				System.out.println("FAILSAFE");

				bar.setValue(0);
			}
		}
    	lastY = e.getY();
	}

	
	public void mouseMoved(MouseEvent e) {
		

	}
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		
    	System.out.println("released");
		try 
    	{
			myCMM.setFixData(ComManager.FIX_0, (byte) 0);
		} 
    	catch (ComException e1) 
    	{
			if(e1.getReason() == ComException.FAILSAFE)
			{
				System.out.println("FAILSAFE");

				bar.setValue(0);
			}
		}

	}
	@Override
	public void keyPressed(KeyEvent e) {
    	System.out.println("pressed");
    	
    	int code = e.getKeyCode();
    	
    	System.out.println("typed code: "+code);
    	if(code == 38)
    	{
    		synchronized(accel)
    		{
    			accel = true;
    		}
    	}
    	if(code == 32)
    	{
			synchronized(braking)
			{
				braking = true;
			}
    		try 
	    	{
				myCMM.setFixData(ComManager.FIX_0, (byte) 0);
			} 
	    	catch (ComException e1) 
	    	{
				if(e1.getReason() == ComException.FAILSAFE)
				{
					System.out.println("FAILSAFE");
	
					bar.setValue(0);
				}
			}
	    	
    	}
		
		
	}
	@Override
	public void keyReleased(KeyEvent e) {
    	int code = e.getKeyCode();
    	
    	System.out.println("typed code: "+code);
    	if(code == 38)
    	{
    		synchronized(accel)
    		{
    			accel = false;
    		}
    	}
    	if(code == 32)
    	{
    		synchronized(braking)
    		{
    			braking = false;
    		}
    	}
		
	}
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void run() {

		int v = 0;
		while(true)
		{
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {

			}
			synchronized(braking)
			{
				if(braking)
					continue;
			}
			
			synchronized(accel)
			{
				if(accel && v < 255)
				{
					v+= 10;
					try 
			    	{
						myCMM.setFixData(ComManager.FIX_0, (byte) v);
					} 
			    	catch (ComException e1) 
			    	{
						if(e1.getReason() == ComException.FAILSAFE)
						{
							System.out.println("FAILSAFE");

							bar.setValue(0);
						}
					}
				}
				
				if(!accel && v>0)
				{
					try 
			    	{
						myCMM.setFixData(ComManager.FIX_0, (byte) v);
					} 
			    	catch (ComException e1) 
			    	{
						if(e1.getReason() == ComException.FAILSAFE)
						{
							System.out.println("FAILSAFE");

							bar.setValue(0);
						}
					}
				   v-=40;	
				}
			}
			
		}
		
	}

}
