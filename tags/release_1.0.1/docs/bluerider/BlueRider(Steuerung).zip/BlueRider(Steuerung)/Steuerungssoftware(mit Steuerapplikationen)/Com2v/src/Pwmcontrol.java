import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JProgressBar;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com_port.ComException;
import com_port.ComListener;
import com_port.ComManager;
import com_port.Message;



public class Pwmcontrol extends JFrame implements ComListener
{
	ComManager myCMM;
	JProgressBar bar;
	JSlider slider1;
	double time;
	

	public Pwmcontrol(ComManager c)
	{
		// TODO Auto-generated constructor stub
		myCMM = c;
		myCMM.addComListener(this,ComManager.FIX_0);
		
		bar = new JProgressBar( 0, 255 );
		slider1 = new JSlider( 0, 255, 0 );
		
	    slider1.addChangeListener( new ChangeListener() { 
	        public void stateChanged( ChangeEvent e ) 
	        { 
	        	byte value = (byte)((JSlider) e.getSource()).getValue();
	        	try 
	        	{
					myCMM.setFixData(ComManager.FIX_0, (byte) value);
				} 
	        	catch (ComException e1) 
	        	{
					if(e1.getReason() == ComException.FAILSAFE)
					{
						System.out.println("FAILSAFE");
						slider1.setValue(0);
						slider1.setValueIsAdjusting(true);
						bar.setValue(0);
					}
				}
	        } 
	      } 
	    ); 
	    
	    this.setMinimumSize(new Dimension(500,80));
		this.setTitle("Controller");
	    
	    
		this.add( bar, BorderLayout.PAGE_START ); 
	    this.add( slider1, BorderLayout.PAGE_END ); 
	}
	@Override
	public void msgReceived(Message m, int index) {

	}
	@Override
	public void fixDataReceived(byte b, int index) 
	{
		short a = (short)(0x00FF & b);
		bar.setValue(a);
		
	}
}